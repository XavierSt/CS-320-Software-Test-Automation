package org.snhu.cs320.appointment;

import java.util.Date;

public class Appointment {
	private String id;
	private Date date;
	private String description;
	
	public Appointment(String id, Date date, String description) throws Exception{
		super();
		
		setId(id);
		setDate(date);
		setDescription(description);
	}
	
	public String getDate() {
		return date.toString();
	}

	public void setDate(Date date) throws Exception{
		if(date == null || date.before(new Date())) {
			throw new Exception("Invalid Date");
		}
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) throws Exception{
		if(description == null || description.trim().length() < 1 || description.length() > 50) {
			throw new Exception("Invalid Description");
		}
		this.description = description;
	}

	public String getId() {
		return id;
	}
	
	private void setId(String id) throws Exception{
		if(id == null || id.trim().length() < 1 || id.length() > 10) {
			throw new Exception("Invalid ID");
		}
		
		this.id = id;
	}
}
