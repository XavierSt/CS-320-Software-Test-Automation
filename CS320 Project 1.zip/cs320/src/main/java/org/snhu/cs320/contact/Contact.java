package org.snhu.cs320.contact;

public class Contact {
	private String id;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String id, String firstName, String lastName, String phone, String address) throws Exception {
		super();
		
		setId(id);
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
	}

	//Calls the first name
	public String getFirstName() {
		return firstName;
	}
	
	//Sets first name
	public void setFirstName(String firstName) throws Exception{
		if(firstName == null || firstName.trim().length() < 1 || firstName.length() > 10) {
			throw new Exception("First Name is Invalid.");
		}
		
		this.firstName = firstName;
	}

	//Calls the last name
	public String getLastName() {
		return lastName;
	}
	
	//Sets the last name
	public void setLastName(String lastName) throws Exception{
		if(lastName == null || lastName.trim().length() < 1 || lastName.length() > 10) {
			throw new Exception("Last Name is Invalid.");
		}
		this.lastName = lastName;
	}

	//Calls the phone number
	public String getPhone() {
		return phone;
	}

	//Sets the phone number
	public void setPhone(String phone) throws Exception{
		if(phone == null || phone.trim().length() < 1 || phone.length() > 10 || phone.matches(".*\\D+.*")) {
			throw new Exception("Phone Number is Invalid.");
		}
		this.phone = phone;
	}

	//Calls the address
	public String getAddress() {
		return address;
	}
	
	//Sets the address
	public void setAddress(String address) throws Exception {
		if(address == null || address.trim().length() < 1 || address.length() > 30) {
			throw new Exception("Address is Invalid.");
		}
		this.address = address;
	}

	//Calls the ID
	public String getId() {
		return id;
	}
	
	//Sets the id but prevents it from being able to manipulate it
	private void setId(String id) throws Exception{
		if(id == null || id.trim().length() < 1 || id.length() > 10) {
			throw new Exception("ID is Invalid.");
		}
		
		this.id = id;
	}
	
	
}
