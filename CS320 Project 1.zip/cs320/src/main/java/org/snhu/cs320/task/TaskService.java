package org.snhu.cs320.task;

import java.util.ArrayList;

public class TaskService {
	public ArrayList<Task> taskList = new ArrayList<Task>();
	int currentId = 0;
	
	//Ads a task to the array
	public void addTask(String name, String description) throws Exception {
		Task task = new Task(Integer.toString(currentId), name, description);
		taskList.add(task);
		
		++currentId;
	}
	
	//Deletes a task from the array
	public void deleteTask(String id)throws Exception {
		for(int i = 0; i < taskList.size(); i++) {
			if(taskList.get(i).getId().equals(id)) {
				taskList.remove(i);
				System.out.println("ID number " + id + " has been deleted.\n");
				break;
			}else if(i == taskList.size()-1) {
				System.out.println("ID number " + id + " doesn't exist.");
				throw new Exception("ID is invalid");
			}
		}
	}
	
	//Updates the name for one of the tasks within the array if it exists
	//Otherwise throws out a statement saying it doesn't exist
	public void updateName(String id, String name) throws Exception {
		for(int i = 0; i < taskList.size(); i++) {
			if(taskList.get(i).getId().equals(id)) {
				taskList.get(i).setName(name);
				break;
			}else if(i == taskList.size()-1) {
				System.out.println("ID number " + id + " doesn't exist.");
				throw new Exception("ID is invalid");
			}
		}
	}
	
	//Updates the description of a task within the array if it exists
	//Otherwise it throws out a statement saying it doesn't exist
	public void updateDescription(String id, String description) throws Exception {
		for(int i = 0; i < taskList.size(); i++) {
			if(taskList.get(i).getId().equals(id)) {
				taskList.get(i).setDescription(description);
				break;
			}else if(i == taskList.size()-1) {
				System.out.println("ID number " + id + " doesn't exist.");
				throw new Exception("ID is invalid");
			}
		}
	}
}
