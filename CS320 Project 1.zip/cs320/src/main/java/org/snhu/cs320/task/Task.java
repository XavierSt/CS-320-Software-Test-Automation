package org.snhu.cs320.task;

public class Task {
	private String id;
	private String name;
	private String description;
	
	public Task(String id, String name, String description) throws Exception {
		super();
		
		setId(id);
		setName(name);
		setDescription(description);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) throws Exception {
		if(name == null || name.trim().length() < 1 || name.length() > 20) {
			throw new Exception("Name is Invalid.");
		}
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) throws Exception {
		if(description == null || description.trim().length() < 1 || description.length() > 50) {
			throw new Exception("Description is Invalid.");
		}
		this.description = description;
	}

	public String getId() {
		return id;
	}
	
	private void setId(String id) throws Exception {
		if(id == null || id.trim().length() < 1 || id.length() > 10) {
			throw new Exception("ID is Invalid.");
		}
		this.id = id;
	}
}
