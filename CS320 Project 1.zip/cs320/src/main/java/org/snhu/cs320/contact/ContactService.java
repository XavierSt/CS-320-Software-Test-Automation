package org.snhu.cs320.contact;

import java.util.ArrayList;

public class ContactService {

	public ArrayList<Contact> contactList = new ArrayList<Contact>();
	int currentID = 0;
	
	//Creates a contact with provided information and then incrementally increases the ID number each time
	//it is called
	public void addContact(String firstName, String lastName, String phone, String address) throws Exception{
		Contact contact = new Contact(Integer.toString(currentID), firstName, lastName, phone, address);
		contactList.add(contact);
		++currentID;
	}
	
	//Deletes a contact from the list by comparing the id to the incremental id 
	public void deleteContact(String id) throws Exception {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				contactList.remove(i);
				System.out.println("ID number " + id + " has been deleted.\n");
				break;
			}else if(i == contactList.size()-1) {
				System.out.println("ID number " + id + " doesn't exist.");
				throw new Exception("ID is invalid");
			}
		}
	}
	
	//Allows a user to update the first name of a contact by calling on the id
	public void updateFirstName(String updatedName, String id)throws Exception {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				contactList.get(i).setFirstName(updatedName);
				break;
			}
			if(i == contactList.size()-1) {
				System.out.println("ID number " + id + " doesn't exist.");
				throw new Exception("ID is invalid");
			}
		}
	}
	
	//Allows a user to update the last name of a contact by calling on the id
	public void updateLastName(String updatedName, String id) throws Exception{
			for(int i = 0; i < contactList.size(); i++) {
				if(contactList.get(i).getId().equals(id)) {
					contactList.get(i).setLastName(updatedName);
					break;
				}
				if(i == contactList.size()-1) {
					System.out.println("ID number " + id + " doesn't exist.");
					throw new Exception("ID is invalid");
				}
			}
		}
	
	//Allows a user to update the phone of a contact by calling on the id
	public void updatePhone(String updatedNumber, String id) throws Exception {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				contactList.get(i).setPhone(updatedNumber);
				break;
			}
			if(i == contactList.size()-1) {
				System.out.println("ID number " + id + " doesn't exist.");
				throw new Exception("ID is invalid");
			}
		}
	}
	
	//Allows a user to update the address of a contact by calling on the id
	public void updateAddress(String updatedAddress, String id) throws Exception {
			for(int i = 0; i < contactList.size(); i++) {
				if(contactList.get(i).getId().equals(id)) {
					contactList.get(i).setAddress(updatedAddress);
					break;
				}
				if(i == contactList.size()-1) {
					System.out.println("ID number " + id + " doesn't exist.");
					throw new Exception("ID is invalid");
				}
			}
		}
	
}
