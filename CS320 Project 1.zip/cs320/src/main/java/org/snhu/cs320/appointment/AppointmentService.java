package org.snhu.cs320.appointment;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	public ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	int currentID = 0;
	
	public void addAppointment(Date date, String description) throws Exception {
		Appointment appointment = new Appointment(Integer.toString(currentID), date, description);
		appointmentList.add(appointment);
		++currentID;
	}
	
	public void deleteAppointment(String id) throws Exception {
		for(int i = 0; i < appointmentList.size(); i++) {
			if(appointmentList.get(i).getId().equals(id)) {
				appointmentList.remove(i);
				System.out.println("ID number " + id + " has been deleted.\n");
				break;
			}else if(i == appointmentList.size()-1) {
				throw new Exception("ID number doesn't exist.");
			}
		}
	}
}
