package org.snhu.cs320.task;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class TaskTest {
	@Test
	//Test to see if the class creates a task correctly
	void testTaskCreation() throws Exception{
		Task task = new Task("1", "Complete Task test", "Finish testing the task creation.");
		assertThat(task)
		.hasFieldOrPropertyWithValue("id", "1")
		.hasFieldOrPropertyWithValue("name", "Complete Task test")
		.hasFieldOrPropertyWithValue("description", "Finish testing the task creation.");
	}
	
	@Test
	//Tests to see if the setters correctly set new names an descriptions
	void testTaskSetter() throws Exception {
		Task task = new Task("1", "Complete Task test", "Finish testing the task creation.");
		task.setName("Test task updater");
		task.setDescription("Finish testing if task correctly updates.");
		assertThat(task)
		.hasFieldOrPropertyWithValue("name", "Test task updater")
		.hasFieldOrPropertyWithValue("description", "Finish testing if task correctly updates.");
	}
	
	@CsvSource({
		"'', Placeholder Task, Test to see if this works", //Blank id
		", Placeholder task, Test to see if this works", //Null id
		"12345678901, Placeholder Task, Test to see if this works", //Too long id
		"1, '', Test to see if this works", //Blank name
		"1,, Test to see if this works", //Null name
		"1, PlaceholderPlaceholder, Test to see if this works", //Too long name
		"1, Placeholder Task, ''", //Blank description
		"1, Placeholder Task,", //Null description
		"1, Placeholder Task, Test to see if this works Test to see if this works" //Too long description
	})
	
	@ParameterizedTest
	//Tests to see if the constructor will throw out an error when id, name, or description is out of parameter  
	void testTaskCreationFailed(String id, String name, String description) {
		assertThatThrownBy(() -> new Task(id, name, description))
		.isNotNull();
	}
	
	@CsvSource({
		",",
		"' ',",
		"PlaceholderPlaceholder"
	})
	
	@ParameterizedTest
	//Tests to see if the setter will throw out a error if trying to change a existing name to one that is invalid
	void testTaskSeterFailed(String name) throws Exception {
		Task task = new Task("1", "Complete Task test", "Finish testing the task creation.");
		assertThatThrownBy(() -> task.setName(name))
		.isNotNull();
	}
}
