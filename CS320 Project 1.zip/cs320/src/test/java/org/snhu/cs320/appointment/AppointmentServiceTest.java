package org.snhu.cs320.appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class AppointmentServiceTest {
	
	//Tests to see if an appointment is made correctly
	@Test
	public void testAddAppointment() throws Exception {
		AppointmentService appointment = new AppointmentService();
		assertTrue(appointment.appointmentList.isEmpty());
		
		//Saves the date for the appointment to add to the constructor
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, 05);
		calendar.set(Calendar.DATE, 05);
		calendar.set(Calendar.YEAR, 2026);
		Date date = calendar.getTime();
		
		appointment.addAppointment(date, "Placeholder to see if this creates correctly");
		
		assertEquals("0", appointment.appointmentList.get(0).getId());
		assertEquals(date.toString(), appointment.appointmentList.get(0).getDate());
		assertEquals("Placeholder to see if this creates correctly", appointment.appointmentList.get(0).getDescription());
		
	}
	
	@Test
	public void testRemoveAppointment() throws Exception {
		AppointmentService appointment = new AppointmentService();
		assertTrue(appointment.appointmentList.isEmpty());
		
		//Saves the date for the appointment to add to the constructor
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, 05);
		calendar.set(Calendar.DATE, 05);
		calendar.set(Calendar.YEAR, 2026);
		Date date = calendar.getTime();
		
		//Creates 3 appointments in the list
		appointment.addAppointment(date, "First placeholder to check for errors");
		appointment.addAppointment(date, "Second placeholder to check for errors");
		appointment.addAppointment(date, "Third placeholder to check for errors");
		
		//Checks to see if there are 3 items in the list
		assertEquals(3, appointment.appointmentList.size());
		appointment.deleteAppointment("1");
		
		assertEquals(2, appointment.appointmentList.size());
		
	}
}
