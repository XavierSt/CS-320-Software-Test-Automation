package org.snhu.cs320.task;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class TaskServiceTest {
	
	@CsvSource({
		"JUnit Testing Phase, Testing to see if the addTask function works.",
		"JUnit Task Testing, Testing to create a second object.",
	})
	
	//Tests to ensure that a task is added correctly to the list and to see if the information
	//is stored correctly
	@ParameterizedTest
	void testAddContact(String name, String description) throws Exception {
		
		TaskService task = new TaskService();
		assertTrue(task.taskList.isEmpty());
		
		task.addTask(name, description);
		
		assertThat(task.taskList.get(0))
		.hasFieldOrPropertyWithValue("name", name)
		.hasFieldOrPropertyWithValue("description", description);
	}
	
	@CsvSource({
		"JUnit Testing Phase, Testing to see if the addTask function works.",
		"JUnit Task Testing, Testing to create a second object.",
	})
	
	//Tests to ensure that the size of the list increases whenever we add a task
	@ParameterizedTest
	void testIncrementTask(String name, String description) throws Exception {
		TaskService task = new TaskService();
		task.addTask("Placeholder Test", "Task to hold this spot");
		task.addTask(name, description);
		
		assertEquals(2, task.taskList.size());
	}
	
	@CsvSource({
		"JUnit Testing Phase, Testing if list will remove a task",
	})
	
	//Tests to ensure that a task can be deleted from the array by checking the size of the array
	@ParameterizedTest
	void testDeleteContact(String name, String description) throws Exception {
		TaskService task = new TaskService();
		assertTrue(task.taskList.isEmpty());
		
		task.addTask("Placeholder Task", "Acts as a placeholder test");
		task.addTask(name, description);
		
		task.deleteTask("0");
		
		assertEquals(1, task.taskList.size());
		
		assertThatThrownBy(() -> task.deleteTask("2"))
		.isNotNull();
	}
	
	@CsvSource({
		"JUnit Testing Phase,"
	})
	
	//Tests to ensure the Task name can be updated
	@ParameterizedTest
	void testUpdateName(String name) throws Exception {
		TaskService task = new TaskService();
		task.addTask("Placeholder Task", "Placeholder task for testing");
		
		task.updateName("0", name);
		assertEquals(name, task.taskList.get(0).getName());
		assertThatThrownBy(() -> task.updateName("2", name))
		.isNotNull();
	}
	
	@CsvSource({
		"Testing to see description can be updated,"
	})
	
	//Tests to ensure the Task description can be update
	@ParameterizedTest
	void testUpdateDescription(String description) throws Exception {
		TaskService task = new TaskService();
		task.addTask("Placeholder task", "Placeholder task for testing");
		
		task.updateDescription("0", description);
		assertEquals(description, task.taskList.get(0).getDescription());
		assertThatThrownBy(() -> task.updateName("2", description))
		.isNotNull();
	}
}
