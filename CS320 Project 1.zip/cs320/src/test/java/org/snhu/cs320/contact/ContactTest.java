package org.snhu.cs320.contact;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class ContactTest {
	
	@Test
	//Tests to see if a created contact has the expected values
	void testContactCreation()throws Exception {
		Contact contact = new Contact("1", "John", "Paul", "3332224444", "1234 Empty Lane");
		assertThat(contact)
			.hasFieldOrPropertyWithValue("id", "1")
			.hasFieldOrPropertyWithValue("firstName", "John")
			.hasFieldOrPropertyWithValue("lastName", "Paul")
			.hasFieldOrPropertyWithValue("phone", "3332224444")
			.hasFieldOrPropertyWithValue("address", "1234 Empty Lane");
	}
	
	//Tests to ensure that the setters correctly change the information in a pre-made contact
	@Test
	void testContactSetters() throws Exception {
		Contact contact = new Contact("1", "John", "Paul", "3332224444", "1234 Empty Lane");
		contact.setFirstName("Jake");
		contact.setLastName("Farm");
		contact.setPhone("1112223333");
		contact.setAddress("4321 Full Lane");
		assertThat(contact)
		.hasFieldOrPropertyWithValue("id", "1")
		.hasFieldOrPropertyWithValue("firstName", "Jake")
		.hasFieldOrPropertyWithValue("lastName", "Farm")
		.hasFieldOrPropertyWithValue("phone", "1112223333")
		.hasFieldOrPropertyWithValue("address", "4321 Full Lane");
	}
	
	@CsvSource({
		"'', John, Paul, 3332224444, 1234 Empty Lane", //Blank ID
		", John, Paul, 3332224444, 1234 Empty Lane", //Null ID
		"12345678901, John, Paul, 3332224444, 1234 Empty Lane", //ID too long
		"1,'', Paul, 3332224444, 1234 Empty Lane", //Blank firstName
		"'',, Paul, 3332224444, 1234 Empty Lane", //Null firstName
		"'', JohnNameTooLong, Paul, 3332224444, 1234 Empty Lane", //firstName too long
		"1, John, '', 3332224444, 1234 Empty Lane", //Blank lastName
		"1, John,, 3332224444, 1234 Empty Lane", //Null lastName
		"1, John, PaulNameTooLong, 3332224444, 1234 Empty Lane", //lastName too long
		"1, John, Paul, '', 1234 Empty Lane", //Blank phone
		"1, John, Paul,, 1234 Empty Lane", //Null phone
		"1, John, Paul, 3332224444123, 1234 Empty Lane", //phone too long
		"1, John, Paul, 33322A4444, 1234 Empty Lane", //Phone with letters
		"1, John, Paul, 33322!4444, 1234 Empty Lane", //Phone with symbols
		"1, John, Paul, 33322 4444, 1234 Empty Lane", //Phone with spaces
		"1, John, Paul, 3332224444, ''", //Blank address
		"1, John, Paul, 3332224444,", //Null address
		"1, John, Paul, 3332224444, 1234 Empty and Full Lane Street", //address too long
		
	})
	
	//Tests to see if that the contact creation will fail if a passed field is incorrect
	@ParameterizedTest
	void testContactCreationFailed(String id, String firstName, String lastName, String phone, String address) {
		assertThatThrownBy(() -> new Contact(id, firstName, lastName, phone, address))
		.isNotNull();
	}
	
	@CsvSource({
		",",
		"' ',",
		"FirstNameTooLong"
	})
	
	//Tests to see if an individual setter can be throw an error when receiving incorrect variables 
	@ParameterizedTest
	void testSettingContactInformation(String firstName) throws Exception {
		Contact contact = new Contact("2", "Jake", "Farm", "1112223333", "4321 Full Lane");
		assertThatThrownBy(() -> contact.setFirstName(firstName))
		.isNotNull();
	}
}
