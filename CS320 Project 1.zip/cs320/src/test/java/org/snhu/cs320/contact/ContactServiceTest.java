package org.snhu.cs320.contact;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class ContactServiceTest {
	

	
	@CsvSource({
		"John, Paul, 3334445555, 1234 Empty Lane",
		"Jake, Lawn, 555333444, 4321 Full Street",
	})
	
	//Tests to ensure that a contact is added correctly to the list and to see if the information
	//is stored correctly
	@ParameterizedTest
	void testAddContact(String firstName, String lastName, String phone, String address) throws Exception {
		
		ContactService contact = new ContactService();
		assertTrue(contact.contactList.isEmpty());
		
		contact.addContact(firstName, lastName, phone, address);
		
		assertEquals(firstName, contact.contactList.get(0).getFirstName());
	}
	
	@CsvSource({
		"John, Paul, 3334445555, 1234 Empty Lane",
		"Jake, Lawn, 555333444, 4321 Full Street",
	})
	
	//Tests to ensure that the size of the list increases whenever we add a contact
	@ParameterizedTest
	void testIncrementContact(String firstName, String lastName, String phone, String address) throws Exception {
		ContactService contact = new ContactService();
		contact.addContact("Steve", "Job", "5556664444", "1212 Fake Street");
		contact.addContact(firstName, lastName, phone, address);
		
		assertEquals(2, contact.contactList.size());
	}
	
	@CsvSource({
		"0, John, Paul, 3334445555, 1234 Empty Lane",
	})
	
	//Tests to ensure that a contact can be deleted from the array by checking the size of the array
	@ParameterizedTest
	void testDeleteContact(String id, String firstName, String lastName, String phone, String address) throws Exception {
		ContactService contact = new ContactService();
		assertTrue(contact.contactList.isEmpty());
		
		contact.addContact("Steve", "Job", "5556664444", "1212 Fake Street");
		contact.addContact(firstName, lastName, phone, address);
		
		contact.deleteContact(id);
		
		assertEquals(1, contact.contactList.size());
		
		assertThatThrownBy(() -> contact.deleteContact("2"))
		.isNotNull();
	}
	
	@CsvSource({
		"John,"
	})
	
	//Tests to ensure the Contact First Name can be updated
	@ParameterizedTest
	void testUpdateFirstName(String firstName) throws Exception {
		ContactService contact = new ContactService();
		contact.addContact("Steve", "Job", "5556664444", "1212 Fake Street");
		
		contact.updateFirstName(firstName, "0");
		assertEquals(firstName, contact.contactList.get(0).getFirstName());
		
		assertThatThrownBy(() -> contact.updateFirstName(firstName, "1"))
		.isNotNull();
	}
	
	@CsvSource({
		"Paul,"
	})
	
	//Tests to ensure the Contact Last Name can be updated
	@ParameterizedTest
	void testUpdateLastName(String lastName) throws Exception {
		ContactService contact = new ContactService();
		contact.addContact("Steve", "Job", "5556664444", "1212 Fake Street");
		
		contact.updateLastName(lastName, "0");
		assertEquals(lastName, contact.contactList.get(0).getLastName());
		
		assertThatThrownBy(() -> contact.updateLastName(lastName, "1"))
		.isNotNull();
	}
	
	@CsvSource({
		"4448887777,"
	})
	
	//Tests to ensure that the Contact Phone Number can be updated
	@ParameterizedTest
	void testUpdatePhone(String phone) throws Exception {
		ContactService contact = new ContactService();
		contact.addContact("Steve", "Job", "5556664444", "1212 Fake Street");
		
		contact.updatePhone(phone, "0");
		assertEquals(phone, contact.contactList.get(0).getPhone());
		assertThatThrownBy(() -> contact.updatePhone(phone, "1"))
		.isNotNull();
	}
	
	@CsvSource({
		"5463 Real Lane,"
	})
	
	
	//Tests to ensure that the Contact Address can be updated
	@ParameterizedTest
	void testUpdateAddress(String address) throws Exception {
		ContactService contact = new ContactService();
		contact.addContact("Steve", "Job", "5556664444", "1212 Fake Street");
		
		contact.updateAddress(address, "0");
		assertEquals(address, contact.contactList.get(0).getAddress());
		
		assertThatThrownBy(() -> contact.updateAddress(address, "1"))
		.isNotNull();
	}
	
}
