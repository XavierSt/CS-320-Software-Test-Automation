package org.snhu.cs320.appointment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class AppointmentTest {
	
	@Test
	void testAppointmentCreation() throws Exception {
		Calendar calendar = Calendar.getInstance();
        
      	calendar.set(Calendar.MONTH, 04);
      	calendar.set(Calendar.DATE, 05);
      	calendar.set(Calendar.YEAR, 2026);
      	
      	Date date = calendar.getTime();
		
		Appointment appointment = new Appointment("1", date, "Check to see if the test works");
		assertThat(appointment)
		.hasFieldOrPropertyWithValue("id", "1")
		.hasFieldOrPropertyWithValue("date", date.toString())
		.hasFieldOrPropertyWithValue("description", "Check to see if the test works");
	}
	
	@CsvSource({
		"'', Check to see if the test works", //Blank id
		"' ', Check to see if the test works", //Blank id with space
		", Check to see if the test works", //Null id
		"12345678901, Check to see if the test works", //Too long id
		"1, ''", //Blank description
		"1, ' '", //Blank description with space
		"1,", //Null description
		"1, Check to see if the test works Check to see if the test works", //Too long description
	})
	
	@ParameterizedTest
	public void testAppointmentErrors(String id, String description) {
		Date date = new Date();
		assertThatThrownBy(() -> new Appointment(id, date, description))
		.isNotNull();
	}
	
	@CsvSource({
		"02, 5, 2026", //Month old
		"03, 1, 2026", //Day old
		"03, 5, 2025", //Year old
	})
	
	@ParameterizedTest
	public void testPastDates(int month, int day, int year) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, month);
		calendar.set(Calendar.DATE, day);
		calendar.set(Calendar.YEAR, year);
		Date date = calendar.getTime();
		
		assertThatThrownBy(() -> new Appointment("1", date, "Check to see if this fails"))
		.isNotNull();
	}
}
